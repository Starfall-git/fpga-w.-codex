set pagination off
set confirm off
set print pretty on
set remotetimeout 30
file firmware/evsoc_tinyml_gesture.elf
target extended-remote localhost:3333
monitor halt
set $pc = _start
monitor resume 0x1000
monitor sleep 4000
monitor halt
print cnn_live_status
print hw_accel_setting
printf "CNN_LIVE %u %u %u %u\n", cnn_live_status.magic,cnn_live_status.stage,cnn_live_status.error,cnn_live_status.completed
monitor resume
disconnect
quit
