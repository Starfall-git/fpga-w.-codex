////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2013-2026 Efinix Inc. All rights reserved.
// See https://github.com/Efinix-Inc/tinyml/blob/main/LICENSE.txt for details.
////////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include <stdint.h>
#include "riscv.h"
#include "soc.h"
#include "bsp.h"
#include "plic.h"
#include "uart.h"
#include <math.h>
#include "print.h"
#include "clint.h"
#include "common.h"
#include "platform/vision/camera.h"
#include "PiCamV3Driver.h"
#include "PiCamDriver.h"
#include "apb3_cam.h"
#include "i2c.h"
#include "userDef.h"
extern "C" {
#include "dmasg.h"
}
#include "axi4_hw_accel.h"

//Arena allocator
#include "model/arena.h"

//Tinyml Header File
#include "intc.h"
#include "tinyml.h"
#include "ops/ops_api.h"

//Import TensorFlow lite libraries
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
//#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/testing/micro_test.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/c/common.h"
#include "tensorflow/lite/micro/debug_log.h"
#include "tensorflow/lite/micro/micro_time.h"
#include "platform/tinyml/profiler.h"

//Model data
#include "model/gesture_int8_model_data.h"
#include "cnn_gesture_data.h"

//Yolo layer
#include "model/yolo.h"


#define SCALE 1
#define CLASSES 1
#define TOTAL_ANCHORS 3
#define NET_HEIGHT 96
#define NET_WIDTH 96
#define OBJECTNESS_THRESHOLD 0.25
#define IOU_THRESHOLD 0.30

#define YOLO_PICO_INPUT_BYTES 96*96*3

#define FRAME_WIDTH     540
#define FRAME_HEIGHT    540


//Set to 4 for multi-buffering; Set to 1 for single buffering (shared for camera frame capture, display, and tinyML pre-processing input).
#define NUM_BUFFER   4
//Start address to be divided evenly by 8. Otherwise DMA tkeep might be shifted, not handled in display and hw_accel blocks.
//BUFFER_START_ADDR should not overlap with memory space allocated for RISC-V program (default.ld)
#define BUFFER_START_ADDR        0x01100000
//Memory gap between BUFFER_START_ADDR and TINYML_INPUT_START_ADDR must sufficient to accommate NUM_BUFFER*FRAME_WIDTH*FRAME_HEIGHT*4 bytes data
#define TINYML_INPUT_START_ADDR  0x01600000
#define BBOX_MAX 16
#define BBOX_CMD_ADDRESS   0x01700000
//The box buffer consist of command , data , and dummy data as padding to ensure that the total data transfer is always even
//DMA controller perform 128-bit word transfer, and our DMA channel will transfer 64-bit word to annotator
//Each transfer initiated from DMA controller will be 128-bit word, thus we need to ensure an even number of transfer
#define TOTAL_BOX_BUFFER   8 + (BBOX_MAX*8) + 8
#define bbox_array ((volatile uint64_t*)BBOX_CMD_ADDRESS)

#define IMAGE_SIZE (FRAME_WIDTH*FRAME_HEIGHT)*4
#define IMAGE_CMD_OFFSET (0)
#define IMAGE_START_OFFSET (IMAGE_CMD_OFFSET + 8)
#define IMAGE_END_OFFSET (IMAGE_START_OFFSET + IMAGE_SIZE)
// The image consists of command, data and dummy data to ensure total data transfer is even , following DMA controller spec.
#define IMAGE_DUMMY_OFFSET (IMAGE_END_OFFSET + 8)
#define TOTAL_BUFFER_SIZE (IMAGE_DUMMY_OFFSET - IMAGE_CMD_OFFSET)

#define tinyml_input_array ((volatile uint8_t*)TINYML_INPUT_START_ADDR)

#define buffer_array       ((volatile uint32_t*)BUFFER_START_ADDR)

uint8_t camera_buffer = 0;
uint8_t display_buffer = 0;
uint8_t next_display_buffer = 0;
uint8_t draw_buffer = 0;
uint8_t bbox_overlay_busy = 0;
uint8_t bbox_overlay_updated = 0;

namespace {
   tflite::ErrorReporter* error_reporter = nullptr;
   const tflite::Model* model = nullptr;
   tflite::MicroInterpreter* interpreter = nullptr;
   TfLiteTensor* model_input = nullptr;

   //Create an area of memory to use for input, output, and other TensorFlow
   //arrays. You'll need to adjust this by combiling, running, and looking
   //for errors.
   constexpr int kTensorArenaSize = 256 * 1024;
   alignas(16) uint8_t tensor_arena[kTensorArenaSize];
   int total_output_layers = 0;
   float anchors[2][TOTAL_ANCHORS * 2] = {{115, 73, 119, 199, 242, 238}, {12, 18, 37, 49, 52, 132}};
}


void tinyml_init() {
   //Set up logging
   static tflite::MicroErrorReporter micro_error_reporter;
   error_reporter = &micro_error_reporter;

   //Map the model into a usable data structure
   model = tflite::GetModel(gesture_int8_model_data);

   if (model->version() != TFLITE_SCHEMA_VERSION) {
      MicroPrintf("Model version does not match Schema\n\r");
      while(1);
   }


   //AllOpsResolver may be used for generalization
   static tflite::AllOpsResolver resolver;
   tflite::MicroOpResolver* op_resolver = nullptr;
   op_resolver = &resolver;

   //Build an interpreter to run the model

   static FullProfiler prof;
   static tflite::MicroInterpreter static_interpreter(
      model, *op_resolver, tensor_arena, kTensorArenaSize,
      error_reporter, nullptr); //Without profiler
      //error_reporter, &prof); //With profiler
   interpreter = &static_interpreter;
   prof.setInterpreter(interpreter);
   prof.setDump(false);
   
   //Allocate memory from the tensor_arena for the model's tensors
   TfLiteStatus allocate_status = interpreter->AllocateTensors();
   if (allocate_status != kTfLiteOk) {
      MicroPrintf("AllocateTensors() failed\n\r");
      while(1);
   }

   //Assign model input buffer (tensor) to pointer
   model_input = interpreter->input(0);

   //Print loaded model input and output shape
   total_output_layers = interpreter->outputs_size();
   MicroPrintf("\n\rTotal output layers: %d\n\r", total_output_layers);
   MicroPrintf(
      "Input shape: %d %d %d %d %d, type: %d\n\r", model_input->dims->size, model_input->dims->data[0], model_input->dims->data[1], model_input->dims->data[2], model_input->dims->data[3], model_input->type
   );

   MicroPrintf("Output tensors: %d\n\r", total_output_layers);

}

// CNN_DDR3_PERIPHERALS: original PiCam/DSI DMA is absent.
#ifdef IO_APB_SLAVE_0_INPUT
u32 buf(u32 i) {
   return BUFFER_START_ADDR +  TOTAL_BUFFER_SIZE*i;
}

static void flush_data_cache(){
   asm(".word(0x500F)");
}

u32 buf_offset(u32 i, u32 offset)
{
    return buf(i) + offset;
}

char* buf_offset_char(u32 i, u32 offset)
{
    return (char*)buf_offset(i, offset);
}

u32* buf_offset_u32(u32 i, u32 offset)
{
    return (u32*)buf_offset(i, offset);
}

u64* buf_offset_u64(u32 i, u32 offset)
{
    return (u64*)buf_offset(i, offset);
}

void send_dma(u32 channel, u32 port, u32 addr, u32 size, int interrupt, int wait, int self_restart) {
   dmasg_input_memory(DMASG_BASE, channel, addr, 16);
   dmasg_output_stream(DMASG_BASE, channel, port, 0, 0, 1);
   
   if(interrupt) {
      dmasg_interrupt_config(DMASG_BASE, channel, DMASG_CHANNEL_INTERRUPT_CHANNEL_COMPLETION_MASK);
   }
   
   if(self_restart) {
      dmasg_direct_start(DMASG_BASE, channel, size, 1);
   } else {
      dmasg_direct_start(DMASG_BASE, channel, size, 0);
   }
   
   if(wait) {
      while(dmasg_busy(DMASG_BASE, channel));
      flush_data_cache();
   }
}

void recv_dma(u32 channel, u32 port, u32 addr, u32 size, int interrupt, int wait, int self_restart) {
   dmasg_input_stream(DMASG_BASE, channel, port, 1, 0);
   dmasg_output_memory(DMASG_BASE, channel, addr, 16);
   
   if(interrupt){
      dmasg_interrupt_config(DMASG_BASE, channel, DMASG_CHANNEL_INTERRUPT_CHANNEL_COMPLETION_MASK);
   }

   if(self_restart) {
      dmasg_direct_start(DMASG_BASE, channel, size, 1);
   } else {
      dmasg_direct_start(DMASG_BASE, channel, size, 0);
   }

   if(wait){
      while(dmasg_busy(DMASG_BASE, channel));
      flush_data_cache();
   }
}

void trigger_next_display_dma() {
   display_buffer = next_display_buffer;
   send_dma(DMASG_DISPLAY_MM2S_CHANNEL, DMASG_DISPLAY_MM2S_PORT, buf(display_buffer), TOTAL_BUFFER_SIZE, 1, 0, 0);
}

void trigger_next_box_dma() {
   if (bbox_overlay_updated) {
      send_dma(DMASG_DISPLAY_MM2S_CHANNEL, DMASG_DISPLAY_MM2S_PORT, BBOX_CMD_ADDRESS, TOTAL_BOX_BUFFER, 0, 1, 0); //Wait till complete
      bbox_overlay_updated = 0;
   }
}

void trigger_next_cam_dma() {
   next_display_buffer = camera_buffer;
   
   for(int i=0; i<NUM_BUFFER; i++)
   {
      if(i!=display_buffer && i!=next_display_buffer && i!=draw_buffer)
      {
         camera_buffer = i;
         break;
      }
   }

   recv_dma(DMASG_CAM_S2MM_CHANNEL, DMASG_CAM_S2MM_PORT, buf_offset(camera_buffer, IMAGE_START_OFFSET), IMAGE_SIZE, 1, 0, 0);

   //Indicate start of S2MM DMA to camera building block via APB3 slave
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG4_OFFSET, 0x00000001);
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG4_OFFSET, 0x00000000);

   //Trigger storage of one captured frame via APB3 slave
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG2_OFFSET, 0x00000001);
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG2_OFFSET, 0x00000000);
}


void color_pattern(volatile u32* buf){
   for (int y=0; y<FRAME_HEIGHT; y++) {
     for (int x=0; x<FRAME_WIDTH; x++) {
       if ((x<3 && y<3) || (x>=FRAME_WIDTH-3 && y<3) || (x<3 && y>=FRAME_HEIGHT-3) || (x>=FRAME_WIDTH-3 && y>=FRAME_HEIGHT-3)) {
         buf [y*FRAME_WIDTH + x] = 0x000000FF; //RED
       } else if (x<(FRAME_WIDTH/4)) {
         buf [y*FRAME_WIDTH + x] = 0x0000FF00; //GREEN
       } else if (x<(FRAME_WIDTH/4 *2)) {
         buf [y*FRAME_WIDTH + x] = 0x00FF0000; //BLUE
       } else if (x<(FRAME_WIDTH/4 *3)) {
         buf [y*FRAME_WIDTH + x] = 0x000000FF; //RED
       } else {
         buf [y*FRAME_WIDTH + x] = 0x00FF0000; //BLUE
       }
     }
   }
}

void init_image(void)
{
    for(int i=0; i<NUM_BUFFER; i++)
    {
    *buf_offset_u64(i, IMAGE_CMD_OFFSET) = 1;
    //Initialize dummy data to be sent with command and data
    *buf_offset_u64(i, IMAGE_DUMMY_OFFSET) = 0;
    }
    color_pattern(buf_offset_u32(display_buffer, IMAGE_START_OFFSET));
}

void init_bbox(void)
{
   //Initialize all box coordinate to invalid, as well as dummy data to be sent with command and data.
   for(int j=0;j<=(BBOX_MAX+1);j++)
   {
      if(j==0){
         bbox_array[j] = 0x0000000000000002;
      } else{
       bbox_array[j] = 0xffffffffffffffff; //Invalid bounding box
    }
   }
   bbox_overlay_updated=1;
}


void init() {
   /************************************************************SETUP PICAM************************************************************/

   MicroPrintf("Camera Setting...\r\n");

   //Assert camera reset
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG1_OFFSET, 0x00000000);
   bsp_uDelay(100);
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG1_OFFSET, 0x00000002);
   bsp_uDelay(1000*10); //10ms delay

   //Camera I2C configuration
   cam0_init(I2C_CTRL_CAM0);

   //Indicate camera configuration done
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG1_OFFSET, 0x00000003);

   bsp_printf("Camera Init...Done\r\n");

   /*************************************************************SETUP DMA*************************************************************/

   MicroPrintf("DMA Setting...");
   dma_init();
   
   dmasg_priority(DMASG_BASE, DMASG_HW_ACCEL_MM2S_CHANNEL, 0, 0);
   dmasg_priority(DMASG_BASE, DMASG_HW_ACCEL_S2MM_CHANNEL, 0, 0);
   dmasg_priority(DMASG_BASE, DMASG_DISPLAY_MM2S_CHANNEL,  3, 0);
   dmasg_priority(DMASG_BASE, DMASG_CAM_S2MM_CHANNEL,      0, 0);
   
   MicroPrintf("Done\n\r");

   /***********************************************************TRIGGER DISPLAY*******************************************************/

   MicroPrintf("Initialize display memory content...");

   //Initialize test image in buffer_array (default buffer 0) 
   init_image();

   MicroPrintf("Done\n\r");
   //Initialize bbox_overlay_buffer - Trigger DMA for initialized bbox_overlay_buffer content to display annotator module!!!
   MicroPrintf("Initialize Bbox to invalid ...");
   init_bbox();
   MicroPrintf("Done\n\r");
   //Trigger display DMA once then the rest handled by interrupt sub-rountine
   MicroPrintf("Trigger display DMA...");
   send_dma(DMASG_DISPLAY_MM2S_CHANNEL, DMASG_DISPLAY_MM2S_PORT, buf(display_buffer), TOTAL_BUFFER_SIZE, 1, 0, 0);
   display_mm2s_active = 1;
   MicroPrintf("Done\n\r");

   msDelay(3000); //Display colour bar for 3 seconds
   
   /*********************************************************TRIGGER CAMERA CAPTURE*****************************************************/
   
   //SELECT RGB or grayscale output from camera pre-processing block.
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG3_OFFSET, 0x00000000);   //RGB

   //Trigger camera DMA once then the rest handled by interrupt sub-rountine
   MicroPrintf("Trigger camera DMA...");
   recv_dma(DMASG_CAM_S2MM_CHANNEL, DMASG_CAM_S2MM_PORT, buf_offset(camera_buffer, IMAGE_START_OFFSET), IMAGE_SIZE, 1, 0, 0);
   cam_s2mm_active = 1;

   //Indicate start of S2MM DMA to camera building block via APB3 slave
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG4_OFFSET, 0x00000001);
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG4_OFFSET, 0x00000000);

   //Trigger storage of one captured frame via APB3 slave
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG2_OFFSET, 0x00000001);
   EXAMPLE_APB3_REGW(EXAMPLE_APB3_SLV, EXAMPLE_APB3_SLV_REG2_OFFSET, 0x00000000);

   MicroPrintf("Done\n\r");

   /***********************************************************TFLITE-MICRO TINYML*******************************************************/

   MicroPrintf("TinyML Setup...");
   u32 hartId = csr_read(mhartid);
   tinyml_init();
   init_accel(hartId);
   print_accel(hartId);
   MicroPrintf("Done\n\r");
}

void draw_boxes(box* boxes,int total_boxes){
   //To store coordinates information
   float min_val = 0.00;
   float max_val = 1.00;
   uint16_t x_min;
   uint16_t x_max;
   uint16_t y_min;
   uint16_t y_max;
   uint64_t box_coordinates;
   float objectness_tresh=0.5;
   int count_boxes=0;

   for (int i = 0; i<(BBOX_MAX); i++) {
      if(i < total_boxes) {
         if(boxes[i].x_min < min_val || boxes[i].y_min < min_val || boxes[i].x_max < min_val|| boxes[i].y_max <min_val || boxes[i].x_min > max_val || boxes[i].y_min > max_val ||  i>total_boxes || boxes[i].objectness < objectness_tresh ){
            bbox_array[i+1] = 0xffffffffffffffff;
         }
         else {
            x_min = (boxes[i].x_min)*FRAME_WIDTH;
            y_min = (boxes[i].y_min)*FRAME_HEIGHT;
            x_max = (boxes[i].x_max)*FRAME_WIDTH;
            y_max = (boxes[i].y_max)*FRAME_HEIGHT;
      
            if(x_max > FRAME_WIDTH){
               x_max = (FRAME_WIDTH-1);
            }
            if(y_max > FRAME_HEIGHT){
               y_max = (FRAME_HEIGHT-1);
            }
            box_coordinates = (uint64_t) x_min << 48 | (uint64_t) y_min << 32 | (uint64_t) x_max << 16 |(uint64_t) y_max << 0;
            bbox_array[i+1] = box_coordinates;
            count_boxes++;
         }
      }
      else {
         bbox_array[i+1] = 0xffffffffffffffff;
      }
   }
   MicroPrintf("Total Boxes : %d\n\r",count_boxes);
   bbox_overlay_updated=1;
}

#endif

// Live entry point for the official EVSoC-derived gesture application.
// AR0135 RAW8 -> fixed center ROI -> 64x64 -> INT8 -> official TinyML Invoke.
#include "gesture_result.h"

struct CnnLiveStatus {
   uint32_t magic, abi_version, stage, error, clint_hz, arena_used;
   uint32_t completed, published, frame, predicted_class;
   int32_t output[3];
   uint32_t invoke_ticks, copy_ticks, period_ticks, input_checksum, input_min, input_max;
   uint32_t capture_errors, publish_busy, requested, pause_after_completed;
};
extern "C" {
   volatile CnnLiveStatus cnn_live_status;
   // TFLM may reuse its input allocation during Invoke. Preserve only when a
   // debugger requests a coherent comparison; normal inference skips this copy.
   volatile int8_t cnn_live_input[4096];
}
static const uintptr_t cnn_apb = IO_APB_SLAVE_1_INPUT;
static void live_stage(uint32_t stage) {
   cnn_live_status.stage = stage;
   asm volatile("fence rw, rw\n.word 0x500f\nfence rw, rw" ::: "memory");
}
static int live_fail(uint32_t error) {
   gesture_set_ready(cnn_apb, 0);
   cnn_live_status.error = error;
   live_stage(255);
   return 1;
}
static bool capture_wait() {
   const uint64_t begin = clint_getTime(BSP_CLINT);
   while (!(read_u32(cnn_apb + 0x44) & 5u)) {
      if (clint_getTime(BSP_CLINT) - begin > uint64_t(SYSTEM_CLINT_HZ)*2u) return false;
   }
   return (read_u32(cnn_apb + 0x44) & 7u) == 1u && read_u32(cnn_apb + 0x58) == 4096;
}
static void capture_request() {
   asm volatile("fence iorw, iorw" ::: "memory");
   write_u32(1, cnn_apb + 0x48);
}
int main() {
   cnn_live_status.magic = 0x474c5631; // GLV1
   cnn_live_status.abi_version = 1;
   cnn_live_status.clint_hz = SYSTEM_CLINT_HZ;
   live_stage(1);
   bsp_init();
   gesture_set_ready(cnn_apb, 0);
   dma_init(); // Official accelerator interrupts; legacy camera DMA remains gated.
   const u32 hart = csr_read(mhartid);
   if (hart != 0) return live_fail(1);
   arena[hart] = arena_create(500000);
   if (!arena[hart]) return live_fail(2);
   live_stage(2);
   tinyml_init();
   init_accel(hart);
   cnn_live_status.arena_used = interpreter->arena_used_bytes();
   TfLiteTensor* output = interpreter->output(0);
   if (interpreter->inputs_size()!=1 || interpreter->outputs_size()!=1 ||
       model_input->type!=kTfLiteInt8 || output->type!=kTfLiteInt8 ||
       model_input->dims->size!=4 || model_input->dims->data[0]!=1 ||
       model_input->dims->data[1]!=64 || model_input->dims->data[2]!=64 ||
       model_input->dims->data[3]!=1 || model_input->bytes!=4096 || output->bytes!=3 ||
       model_input->params.scale!=cnn_input_scale || model_input->params.zero_point!=-128 ||
       output->params.scale!=cnn_output_scale || output->params.zero_point!=cnn_output_zero_point)
      return live_fail(3);
   if (read_u32(cnn_apb+0x40)!=0x43415031 ||
       read_u32(cnn_apb+0x50)!=((104u<<16)|384u) ||
       read_u32(cnn_apb+0x54)!=((616u<<16)|896u)) return live_fail(4);
   live_stage(3);
   capture_request();
   if (!capture_wait()) return live_fail(5);
   gesture_set_ready(cnn_apb, 1);
   bool enabled_before = false;
   uint64_t previous_begin = 0;
   for (;;) {
      cnn_live_status.requested = gesture_inference_enabled(cnn_apb);
      if (!cnn_live_status.requested) {
         enabled_before = false;
         live_stage(4); // Initialized and camera verified; waiting for UART enable.
         msDelay(20);
         continue;
      }
      if (!enabled_before) {
         // Discard a snapshot held while disabled; wait for an outstanding capture.
         if (!capture_wait()) return live_fail(6);
         capture_request();
         enabled_before = true;
      }
      live_stage(5);
      if (!capture_wait()) {
         cnn_live_status.capture_errors++;
         return live_fail(7); // No stale frame inference after a camera fault.
      }
      if (!gesture_inference_enabled(cnn_apb)) continue;
      const uint64_t begin = clint_getTime(BSP_CLINT);
      cnn_live_status.period_ticks = previous_begin ? uint32_t(begin-previous_begin) : 0;
      previous_begin = begin;
      cnn_live_status.frame = read_u32(cnn_apb+0x4c);
      uint32_t checksum=2166136261u, lo=255, hi=0;
      const bool preserve_input = cnn_live_status.pause_after_completed != 0;
      for (unsigned word=0; word<1024; ++word) {
         uint32_t raw = read_u32(cnn_apb+0x1000+4*word);
         for (unsigned byte=0; byte<4; ++byte) {
            const uint32_t pixel = (raw>>(8*byte))&255u;
            // Defined signed conversion; identical to uint8 XOR 0x80 in memory.
            model_input->data.int8[4*word+byte] = int(pixel)-128;
            if (preserve_input) cnn_live_input[4*word+byte] = int(pixel)-128;
            checksum = (checksum ^ pixel)*16777619u;
            if (pixel<lo) lo=pixel;
            if (pixel>hi) hi=pixel;
         }
      }
      cnn_live_status.input_checksum=checksum;
      cnn_live_status.input_min=lo; cnn_live_status.input_max=hi;
      cnn_live_status.copy_ticks=uint32_t(clint_getTime(BSP_CLINT)-begin);
      capture_request(); // RAM ownership returned only after all input bytes copied.
      if (!gesture_inference_enabled(cnn_apb)) continue;
      live_stage(6);
      const uint64_t invoke_begin=clint_getTime(BSP_CLINT);
      if (interpreter->Invoke()!=kTfLiteOk) return live_fail(8);
      cnn_live_status.invoke_ticks=uint32_t(clint_getTime(BSP_CLINT)-invoke_begin);
      unsigned cls=0;
      for (unsigned k=0; k<3; ++k) {
         cnn_live_status.output[k]=output->data.int8[k];
         if (output->data.int8[k]>output->data.int8[cls]) cls=k;
      }
      cnn_live_status.predicted_class=cls;
      cnn_live_status.completed++;
      if (gesture_inference_enabled(cnn_apb)) {
         // This is the classification ROI, not an object detection bounding box.
         int sent=gesture_publish_result(cnn_apb,cnn_live_status.frame,384,104,896,616,1,cls);
         if (sent==1) cnn_live_status.published++;
         else cnn_live_status.publish_busy++;
      }
      live_stage(7);
      // Optional JTAG inspection of a coherent input/output pair, no breakpoints.
      while (cnn_live_status.pause_after_completed &&
             cnn_live_status.completed>=cnn_live_status.pause_after_completed) {
         live_stage(8);
         msDelay(10);
      }
   }
}
