set pagination off
set confirm off
set print pretty on
set remotetimeout 30
file firmware/evsoc_tinyml_gesture.elf
target extended-remote localhost:3333
monitor halt
monitor debug_level 1
monitor adapter speed 800
set $pc = _start
monitor resume 0x1000
monitor sleep 10000
monitor halt
print hw_accel_setting
print cnn_debug_status
printf "CNN_RESULT %u %u %u %u %u\n", cnn_debug_status.magic, cnn_debug_status.stage, cnn_debug_status.error, cnn_debug_status.completed, cnn_debug_status.passed
set $cnn_sample = 0
while $cnn_sample < 3
printf "CNN_VECTOR %d %d %d %d %u %u\n", $cnn_sample, cnn_debug_status.actual[$cnn_sample][0], cnn_debug_status.actual[$cnn_sample][1], cnn_debug_status.actual[$cnn_sample][2], cnn_debug_status.ticks_hi[$cnn_sample], cnn_debug_status.ticks_lo[$cnn_sample]
set $cnn_sample = $cnn_sample + 1
end
monitor reg pc
monitor reg mcause
monitor reg mepc
monitor reg mtval
disconnect
quit
