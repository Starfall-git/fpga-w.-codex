set pagination off
set confirm off
set print pretty on
set remotetimeout 30
file firmware/evsoc_tinyml_gesture.elf
target extended-remote localhost:3333
monitor halt
monitor debug_level 1
monitor adapter speed 800
load
monitor reset halt
compare-sections
monitor halt
disconnect
quit
