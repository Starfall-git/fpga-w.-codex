﻿param([string]$Sdk = 'C:\Users\SteLl1a\Desktop\Work\FPGA_Contest\env\RISCV-IDE')
$ErrorActionPreference = 'Stop'
$exe = Join-Path $Sdk 'toolchain/bin/riscv-none-elf-gdb.exe'
if (!(Test-Path -LiteralPath $exe)) { throw "GDB not found: $exe" }
Push-Location $PSScriptRoot
try {
    $ErrorActionPreference = 'Continue'
    $verify = & $exe -batch -x debug/load-verify.gdb 2>&1
    $code = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    $verify | Tee-Object -FilePath load-verify.log
    $sections = @($verify | Where-Object { "$_" -match '^Section ' })
    if ($code -ne 0 -or $sections.Count -ne 5 -or @($sections | Where-Object { "$_" -notmatch ': matched\.$' }).Count -ne 0) {
        throw 'ELF readback failed; execution was not started.'
    }
    $ErrorActionPreference = 'Continue'
    $run = & $exe -batch -x debug/run-static.gdb 2>&1
    $code = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    $run | Tee-Object -FilePath run-static.log
    if ($code -ne 0) { throw "GDB exited with $code" }
    if (($run -join "`n") -notmatch 'CNN_RESULT 1195655729 9 0 3 3') {
        Write-Warning 'Read CNN_RESULT above. completed=3 means ELF ran all vectors. This r3 baseline reports stage=255,error=5,passed=1: two outputs differ by one INT8 unit.'
        exit 2
    }
    Write-Output 'PASS: all three INT8 vectors match.'
} finally { Pop-Location }
