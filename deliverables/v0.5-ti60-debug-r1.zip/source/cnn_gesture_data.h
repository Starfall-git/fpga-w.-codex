// Generated model contract. C-compatible declarations; compile .cc as C++11.
#ifndef CNN_GESTURE_DATA_H
#define CNN_GESTURE_DATA_H
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
#define CNN_INPUT_BYTES 4096
#define CNN_OUTPUT_CLASSES 3
#define CNN_GOLDEN_COUNT 3
extern const uint8_t cnn_model_data[];
extern const size_t cnn_model_data_len;
extern const char* const cnn_class_names[CNN_OUTPUT_CLASSES];
extern const float cnn_input_scale, cnn_output_scale;
extern const int32_t cnn_input_zero_point, cnn_output_zero_point;
extern const int8_t cnn_golden_0_input[4096];
extern const int8_t cnn_golden_0_output[3];
extern const int8_t cnn_golden_1_input[4096];
extern const int8_t cnn_golden_1_output[3];
extern const int8_t cnn_golden_2_input[4096];
extern const int8_t cnn_golden_2_output[3];
#ifdef __cplusplus
}
#endif
#endif
