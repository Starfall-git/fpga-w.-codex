"""V0.6 / 28: direct controls, latest-value queue, low-latency status updates."""
import argparse
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import queue
import time
from .snapshots import FrameStore
from .ddr_store import store_status, store_control, FrameCatalog
from .hdmi_source import USBCaptureSource, HDMIPreview
from .frame_gallery import Gallery
import tkinter as tk
from tkinter import ttk, simpledialog
from PIL import ImageTk
import threading
from .client import SerialClient, DemoClient, list_ports
from .protocol import (CAP_THRESHOLD, CAP_FLIP, CAP_CROP, CAP_ZOOM, CAP_ISP, CAP_MEDIAN,
                       CAP_DEFAULTS, threshold_payload, crop_payload, percent_ratio)


class ImageControlApp:
    def __init__(self, root, demo=False, hdmi_source=None):
        self.root = root
        root.title('VF-Ti60 · 实时图像控制台')
        # V0.16: reserve the extra algorithm row so DDR controls remain visible.
        root.geometry('1000x800')
        root.minsize(950, 770)
        self.executor = ThreadPoolExecutor(max_workers=1)
        self.events = queue.Queue()
        self.pending = OrderedDict()
        self.client = None
        self.busy = self.closing = self.resetting = False
        self.caps = 0
        self.inflight_kind = None
        self.last_interaction = 0.0
        self.mode = tk.StringVar(value='模拟演示' if demo else '串口硬件')
        self.port, self.baud = tk.StringVar(), tk.StringVar(value='115200')
        self.threshold, self.readback = tk.StringVar(value='128'), tk.StringVar(value='—')
        self.connection = tk.StringVar(value='未连接')
        self.message = tk.StringVar(value='连接设备后，阈值与缩放输入回车生效，开关点击即生效。')
        self.cap_text = tk.StringVar(value='')
        self.geometry_readback = tk.StringVar(value='尚未读取图像设置')
        self.mode_readback = tk.StringVar(value='当前模式：—')
        self.latency = tk.StringVar(value='')
        self.flip, self.flip_horizontal = tk.BooleanVar(), tk.BooleanVar()
        # V0.9 / 46: Median is independent of Sobel and defaults off.
        self.sobel, self.inverted, self.median = tk.BooleanVar(), tk.BooleanVar(), tk.BooleanVar()
        self.crop = {k: tk.StringVar(value=v) for k,v in (('x','0'),('y','0'),('width','1280'),('height','720'))}
        self.zoom = tk.StringVar(value='100%')
        self.auto_poll = tk.BooleanVar(value=True)
        self.show_log = tk.BooleanVar(value=False)
        # V0.15 / 73: serial controls DDR IDs; HDMI adapter supplies host pixels.
        self.frame_store=FrameStore()
        self.snapshot_busy=False;self.frame_frozen=False;self.snapshot_available=False
        self.gallery=None
        self.ddr_catalog=FrameCatalog();self.ddr_selected={};self.ddr_thumb_cancel=threading.Event()
        self.hdmi_source=hdmi_source or USBCaptureSource();self.ddr_status=None;self.ddr_window=None
        self.gaussian=tk.BooleanVar();self.scharr=tk.BooleanVar();self.canny=tk.BooleanVar();self.preserve=tk.BooleanVar()
        self.advanced_controls=[];self.advanced_available=False
        self.controls = []
        self._build()
        self.refresh_ports()
        root.protocol('WM_DELETE_WINDOW', self.close)
        self._drain_id=root.after(5, self._drain)
        self._poll_id=root.after(1500, self._poll)
        self._states()

    def _build(self):
        style = ttk.Style()
        if 'clam' in style.theme_names(): style.theme_use('clam')
        for cls in ('TFrame','TLabel','TLabelframe'):
            style.configure(cls, background='#f3f5f8')
        style.configure('TLabel', font=('Microsoft YaHei UI',10))
        style.configure('TButton', padding=(10,6), font=('Microsoft YaHei UI',10))
        style.configure('Title.TLabel', font=('Microsoft YaHei UI',20,'bold'), foreground='#17364c')
        main = ttk.Frame(self.root, padding=20)
        main.pack(fill='both', expand=True)
        ttk.Label(main, text='实时图像控制台', style='Title.TLabel').pack(anchor='w')
        # V0.16 / 78: expose the new processing choices without a second apply step.
        ttk.Label(main, text='VF-Ti60F225   /   HDMI 720p · 降噪、Sobel / Scharr / Canny 与几何变换').pack(anchor='w',pady=(4,12))
        connection = ttk.LabelFrame(main,text='连接',padding=10)
        connection.pack(fill='x')
        self.mode_box = ttk.Combobox(connection,textvariable=self.mode,values=('串口硬件','模拟演示'),width=10,state='readonly')
        self.mode_box.pack(side='left',padx=4)
        self.port_box = ttk.Combobox(connection,textvariable=self.port,width=10,state='readonly')
        self.port_box.pack(side='left',padx=4)
        self.refresh_button = ttk.Button(connection,text='刷新',command=self.refresh_ports)
        self.refresh_button.pack(side='left',padx=4)
        ttk.Label(connection,text='波特率').pack(side='left',padx=6)
        self.baud_entry = ttk.Entry(connection,textvariable=self.baud,width=8)
        self.baud_entry.pack(side='left')
        self.connect_button = ttk.Button(connection,text='连接',command=self.toggle_connection)
        self.connect_button.pack(side='left',padx=12)
        ttk.Label(connection,textvariable=self.connection).pack(side='left')

        image = ttk.LabelFrame(main,text='图像',padding=12)
        image.pack(fill='x',pady=12)
        row = ttk.Frame(image); row.pack(fill='x')
        for text, variable, cap in (('Sobel 边缘检测',self.sobel,CAP_ISP),
                                    ('选择性中值滤波',self.median,CAP_MEDIAN),
                                    ('黑白反转',self.inverted,CAP_ISP)):
            button=ttk.Checkbutton(row,text=text,variable=variable,command=lambda v=variable:self.apply_isp("sobel" if v is self.sobel else None))
            button.pack(side='left',padx=(0,20)); self.controls.append((button,cap))
        ttk.Label(row,text='阈值').pack(side='left',padx=(10,6))
        self.threshold_entry=ttk.Entry(row,textvariable=self.threshold,width=9,font=('Consolas',14))
        self.threshold_entry.pack(side='left'); self.controls.append((self.threshold_entry,CAP_THRESHOLD))
        self.threshold_entry.bind('<Return>',lambda _: self.apply_threshold())
        ttk.Label(row,text='0=参考原强度；增大可抑制弱边缘，>1020无边缘 · 回车生效').pack(side='left',padx=10)
        advanced=ttk.Frame(image);advanced.pack(fill='x',pady=(8,0))
        for label,var,edge in [('高斯滤波',self.gaussian,None),('保边降噪（需高斯）',self.preserve,None),('Scharr',self.scharr,'scharr'),('Canny',self.canny,'canny')]:
            widget=ttk.Checkbutton(advanced,text=label,variable=var,command=lambda e=edge:self.apply_isp(e))
            widget.pack(side='left',padx=(0,14));self.advanced_controls.append(widget)
        # V0.19 / 88-91: secondary panel keeps main controls compact.
        self.tuning_button=ttk.Button(advanced,text='曝光 / 算法调节',command=self.open_tuning)
        self.tuning_button.pack(side='right')
        self.cnn_button=ttk.Button(advanced,text='TinyML 手势',command=self.open_cnn)
        self.cnn_button.pack(side='right',padx=6)
        ttk.Label(image,text='边缘算法互斥；Canny自动启用高斯。曝光和滤波强度可在右侧调节。').pack(anchor='w',pady=(3,0))
        ttk.Label(image,textvariable=self.mode_readback,foreground='#137c70').pack(anchor='w',pady=(10,0))
        info=ttk.Frame(image); info.pack(fill='x',pady=(4,0))
        ttk.Label(info,text='设备阈值：').pack(side='left')
        ttk.Label(info,textvariable=self.readback,foreground='#137c70').pack(side='left')
        ttk.Label(info,textvariable=self.latency,foreground='#64748b').pack(side='right')

        transform=ttk.LabelFrame(main,text='翻转、缩放与裁剪',padding=12)
        transform.pack(fill='x')
        row=ttk.Frame(transform); row.pack(fill='x')
        for text,variable in (('上下翻转',self.flip),('左右翻转',self.flip_horizontal)):
            button=ttk.Checkbutton(row,text=text,variable=variable,command=lambda: self.apply_feature('flip'))
            button.pack(side='left',padx=(0,20)); self.controls.append((button,CAP_FLIP))
        ttk.Label(row,text='缩放').pack(side='left',padx=(15,5))
        self.zoom_box=ttk.Combobox(row,textvariable=self.zoom,values=('10%','25%','50%','100%','150%','200%','300%','400%','500%'),width=10)
        self.zoom_box.pack(side='left'); self.controls.append((self.zoom_box,CAP_ZOOM))
        self.zoom_box.bind('<<ComboboxSelected>>',lambda _: self.apply_feature('zoom'))
        self.zoom_box.bind('<Return>',lambda _: self.apply_feature('zoom'))
        ttk.Label(row,text='10%–500% · 可输入，回车生效').pack(side='left',padx=10)
        row=ttk.Frame(transform); row.pack(fill='x',pady=12)
        for name,label in (('x','X'),('y','Y'),('width','宽'),('height','高')):
            ttk.Label(row,text=label).pack(side='left',padx=(0,5))
            entry=ttk.Entry(row,textvariable=self.crop[name],width=7)
            entry.pack(side='left',padx=(0,12)); self.controls.append((entry,CAP_CROP))
            entry.bind('<Return>',lambda _: self.apply_feature('crop'))
        crop_button=ttk.Button(row,text='裁剪',command=lambda: self.apply_feature('crop'))
        crop_button.pack(side='left'); self.controls.append((crop_button,CAP_CROP))
        self.defaults_button=ttk.Button(row,text='默认',command=self.reset_defaults)
        self.defaults_button.pack(side='right')
        ttk.Label(transform,text='居中显示：缩小补黑，放大截取。黑白反转作用于边缘检测；“默认”保留阈值。',foreground='#64748b').pack(anchor='w')
        ttk.Label(transform,textvariable=self.geometry_readback,wraplength=880,foreground='#137c70').pack(fill='x',pady=(8,0))
        ttk.Label(main,textvariable=self.message,wraplength=900).pack(fill='x',pady=12)
        row=ttk.Frame(main); row.pack(fill='x')
        ttk.Checkbutton(row,text='通信记录',variable=self.show_log,command=self._toggle_log).pack(side='left')
        ttk.Label(row,textvariable=self.cap_text,foreground='#64748b').pack(side='right')
        framebar=ttk.Frame(main,padding=(0,8));framebar.pack(fill='x')
        self.freeze_button=ttk.Button(framebar,text='记录帧',command=self.capture_frame)
        self.freeze_button.pack(side='left')
        self.pause_button=ttk.Button(framebar,text='帧冻结',command=lambda:self.ddr_action(2))
        self.pause_button.pack(side='left',padx=5)
        self.resume_button=ttk.Button(framebar,text='实时显示',command=self.resume_video)
        self.resume_button.pack(side='left')
        self.ddr_button=ttk.Button(framebar,text='DDR冻结帧仓库',command=self.open_ddr_store)
        self.ddr_button.pack(side='left',padx=5)
        ttk.Button(framebar,text='本地图片仓库',command=self.open_gallery).pack(side='right')
        ttk.Button(framebar,text='HDMI预览',command=self.open_hdmi_preview).pack(side='right',padx=5)
        self.ddr_text=tk.StringVar(value='DDR仓库：未连接')
        ttk.Label(main,textvariable=self.ddr_text).pack(anchor='w')
        self.log_frame=ttk.Frame(main)
        self.log=tk.Text(self.log_frame,height=6,wrap='word',font=('Consolas',9),background='#142735',foreground='#d7e5ee',state='disabled')
        scroll=ttk.Scrollbar(self.log_frame,command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y'); self.log.pack(fill='both',expand=True)

    def open_cnn(self):
        from .cnn_controls import CnnPanel
        panel=getattr(self,'cnn_panel',None)
        if panel and panel.window.winfo_exists():
            panel.window.lift();panel.refresh()
        else:
            self.cnn_panel=CnnPanel(self)

    def open_tuning(self):
        from .camera_controls import ControlPanel
        if getattr(self,'tuning_panel',None) and self.tuning_panel.window.winfo_exists():
            self.tuning_panel.window.lift();return
        self.tuning_panel=ControlPanel(self)

    def _toggle_log(self):
        if self.show_log.get(): self.log_frame.pack(fill='both',expand=True,pady=(6,0))
        else: self.log_frame.pack_forget()

    def _states(self):
        connected=self.client is not None
        for widget in (self.mode_box,self.port_box): widget.configure(state='disabled' if connected or self.busy else 'readonly')
        self.baud_entry.configure(state='disabled' if connected or self.busy else 'normal')
        self.refresh_button.configure(state='disabled' if connected or self.busy else 'normal')
        self.connect_button.configure(text='断开' if connected else '连接',state='disabled' if self.busy or self.pending else 'normal')
        # V0.6: edits remain usable while a packet is in flight; latest values are queued.
        for widget,cap in self.controls:
            widget.configure(state='normal' if connected and not self.resetting and not (self.ddr_status and self.ddr_status.mode==3 and cap & (CAP_FLIP|CAP_CROP|CAP_ZOOM)) and self.caps & cap else 'disabled')
        self.defaults_button.configure(state='normal' if connected and not self.resetting and not self.frame_frozen and not self.snapshot_busy and self.caps & CAP_DEFAULTS else 'disabled')

        for widget in self.advanced_controls:
            widget.configure(state='normal' if connected and self.advanced_available and not self.resetting else 'disabled')
        self.tuning_button.configure(state='normal' if connected and (self.client.simulated or (self.client.status and self.client.status.advanced_capabilities & 16)) and not self.resetting else 'disabled')
        enabled=connected and self.snapshot_available and not self.busy and not self.pending
        for widget in (self.freeze_button,self.pause_button,self.resume_button,self.ddr_button):
            widget.configure(state='normal' if enabled else 'disabled')
        if self.ddr_status and self.ddr_status.mode!=0:self.freeze_button.configure(state='disabled')
        if getattr(self,'cnn_panel',None):self.cnn_panel.sync()

    def _store_status(self,status):
        previous=set(self.ddr_catalog.entries)
        self.ddr_catalog.sync(status.saved,status.orders)
        if getattr(self,'_record_pending',False):
            for slot in set(status.saved)-previous:self.ddr_catalog.entries[slot]['time']=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self._record_pending=False
        self.ddr_status=status
        # V0.15: pause/replay do not lock ISP settings; UART carries no pixels.
        self.frame_frozen=False
        modes=('实时显示','帧冻结','单帧回放','多帧对比')
        self.ddr_text.set(f'DDR已存 {len(status.saved)}/{status.capacity} 帧 · {modes[status.mode]} · 断电/复位后编号失效')
        if self.ddr_window is not None and self.ddr_window.winfo_exists():self._refresh_ddr_list()

    def ddr_action(self,action,frame_id=0,selection=()):
        if not self.client:return
        backend=self.client
        def done(status):
            self._record_pending=action==1
            self._store_status(status)
            self.message.set(('已恢复实时显示','已记录当前帧，直播继续','当前画面已冻结，后台采集继续','已回放所选帧','HDMI已切换为多帧对比','DDR仓库已清空','已删除选中帧并恢复实时')[action])
        self._submit(lambda:store_control(backend,action,frame_id,selection),done,f'ddr_delete_{frame_id}' if action==6 else 'ddr')

    def open_ddr_store(self):
        if self.ddr_window is not None and self.ddr_window.winfo_exists():self.ddr_window.lift();return
        self.ddr_window=tk.Toplevel(self.root);self.ddr_window.title('DDR冻结帧仓库');self.ddr_window.geometry('1000x750')
        self.ddr_window.protocol('WM_DELETE_WINDOW',self.close_ddr_store)
        ttk.Label(self.ddr_window,textvariable=self.ddr_text,padding=10).pack(fill='x')
        ttk.Label(self.ddr_window,text='按记录顺序排列；勾选图片，右上角×删除；编号可修改但不能重复。').pack()
        self.ddr_hint=tk.StringVar(value='缩略图需回放到HDMI后读取；更新时会短暂切换显示，完成后恢复实时。')
        ttk.Label(self.ddr_window,textvariable=self.ddr_hint,wraplength=950).pack(fill='x',padx=12,pady=5)
        bar=ttk.Frame(self.ddr_window);bar.pack(fill='x',padx=12,pady=10)
        for text,command in [('回放选中帧',self.replay_selected),('HDMI对比所选',self.compare_selected),('读取缩略图',self.read_ddr_thumbnails),('修改编号',self.rename_ddr)]:
            ttk.Button(bar,text=text,command=command).pack(side='left',padx=4)
        ttk.Button(bar,text='清空DDR仓库',command=lambda:self.ddr_action(5)).pack(side='right')
        self.ddr_canvas=tk.Canvas(self.ddr_window,highlightthickness=0)
        scroll=ttk.Scrollbar(self.ddr_window,command=self.ddr_canvas.yview);scroll.pack(side='right',fill='y')
        self.ddr_canvas.configure(yscrollcommand=scroll.set);self.ddr_canvas.pack(fill='both',expand=True)
        self.ddr_inner=ttk.Frame(self.ddr_canvas);self.ddr_canvas.create_window(0,0,window=self.ddr_inner,anchor='nw')
        self.ddr_inner.bind('<Configure>',lambda _:self.ddr_canvas.configure(scrollregion=self.ddr_canvas.bbox('all')))
        self._refresh_ddr_list()
        if self.ddr_catalog.entries:self.read_ddr_thumbnails()

    def close_ddr_store(self):
        self.ddr_thumb_cancel.set();self.pending.pop('ddr_thumbnails',None);self.pending.pop('ddr',None)
        self.ddr_window.destroy();self.ddr_window=None
        self.ddr_action(0)

    def _refresh_ddr_list(self):
        selected={s for s,v in self.ddr_selected.items() if v.get()}
        self.ddr_selected={};self.ddr_photos=[]
        for child in self.ddr_inner.winfo_children():child.destroy()
        for index,slot in enumerate(self.ddr_catalog.ordered()):
            item=self.ddr_catalog.entries[slot]
            cell=ttk.Frame(self.ddr_inner,padding=10);cell.grid(row=index//3,column=index%3,sticky='nsew')
            area=ttk.Frame(cell,width=290,height=164);area.pack();area.pack_propagate(False)
            thumb=item['thumbnail']
            if thumb is not None:
                image=thumb.copy();image.thumbnail((290,164));photo=ImageTk.PhotoImage(image,master=self.ddr_window);self.ddr_photos.append(photo)
                label=ttk.Label(area,image=photo,anchor='center')
            else:label=ttk.Label(area,text='尚未读取缩略图',anchor='center')
            label.pack(fill='both',expand=True)
            var=tk.BooleanVar(value=slot in selected);self.ddr_selected[slot]=var
            delete=ttk.Button(area,text='×',width=2,command=lambda s=slot:self.ddr_action(6,s))
            def choose(v=var,d=delete):
                if v.get():d.place(relx=1,x=-2,y=2,anchor='ne')
                else:d.place_forget()
            if var.get():choose()
            label.bind('<Button-1>',lambda _,v=var,c=choose:(v.set(not v.get()),c()))
            ttk.Checkbutton(cell,text=f"编号 {item['number']}",variable=var,command=choose).pack()
            ttk.Label(cell,text=item['time'] or '连接前已存在 · 时间未知').pack()

    def rename_ddr(self):
        slots=[s for s,v in self.ddr_selected.items() if v.get()]
        if len(slots)!=1:self.message.set('请选中一张图片修改编号');return
        slot=slots[0];number=simpledialog.askinteger('修改编号','输入不重复的正整数编号：',initialvalue=self.ddr_catalog.entries[slot]['number'],minvalue=1,parent=self.ddr_window)
        if number is not None:
            try:self.ddr_catalog.rename(slot,number);self._refresh_ddr_list()
            except ValueError as e:self.ddr_hint.set(str(e))

    def replay_selected(self):
        selected=[s for s,v in self.ddr_selected.items() if v.get()]
        if len(selected)!=1:self.message.set('请选择一张DDR帧进行回放');return
        self.ddr_action(3,selected[0])

    def compare_selected(self):
        selected=[s for s,v in self.ddr_selected.items() if v.get()]
        if not selected:self.message.set('请选择需要对比的DDR帧');return
        self.ddr_action(4,selection=selected)

    def read_ddr_thumbnails(self):
        if not self.client or not self.ddr_window:return
        if self.busy:self.ddr_hint.set('当前命令尚未完成，请稍后读取缩略图。');return
        slots=self.ddr_catalog.ordered()
        if not slots:return
        backend=self.client;source=self.hdmi_source;self.ddr_thumb_cancel=threading.Event();cancel=self.ddr_thumb_cancel
        self.ddr_hint.set('正在依次回放读取缩略图…完成后自动恢复实时显示。')
        def operation():
            images={}
            if backend.simulated:raise RuntimeError('模拟DDR编号没有真实像素，不生成伪缩略图')
            if not source.available and not getattr(source,'running',False):
                devices=source.devices() if hasattr(source,'devices') else []
                index=next((i for i,n in devices if 'hagibis' in n.lower()),None)
                if index is None:raise RuntimeError('请在HDMI预览中选择采集卡并开始采集')
                source.start(index)
            try:
                for slot in slots:
                    if cancel.is_set():break
                    store_control(backend,3,slot)
                    # HDMI/UVC has no DDR-ID tag. Wait out the capture pipeline,
                    # then select a newly received frame from the static replay.
                    ready=time.monotonic()+1.0;deadline=ready+4
                    while not cancel.is_set():
                        frame=source.latest()
                        if frame is not None and frame.timestamp>=ready:
                            image=frame.image.copy();image.thumbnail((580,328));images[slot]=image;break
                        if time.monotonic()>deadline:raise RuntimeError('读取缩略图超时，请检查HDMI预览通路')
                        cancel.wait(.03)
            finally:store_control(backend,0)
            return images,store_status(backend)
        def done(result):
            images,status=result
            for slot,image in images.items():
                if slot in self.ddr_catalog.entries:self.ddr_catalog.entries[slot]['thumbnail']=image
            self._store_status(status)
            if self.ddr_window:self.ddr_hint.set(f'已读取 {len(images)} 张缩略图，并恢复实时显示。')
        self._submit(operation,done,'ddr_thumbnails')

    def open_gallery(self):
        if self.gallery is not None and self.gallery.win.winfo_exists():
            self.gallery.refresh();self.gallery.win.lift()
        else:self.gallery=Gallery(self.root,self.frame_store)

    def capture_frame(self):self.ddr_action(1)
    def resume_video(self):self.ddr_action(0)

    def _trace(self,direction,raw): self.events.put(('log',f'{direction}  {raw.hex(" ").upper()}'))

    def _log(self,message):
        self.log.configure(state='normal')
        self.log.insert('end',datetime.now().strftime('%H:%M:%S')+'  '+message+'\n')
        if int(self.log.index('end-1c').split('.')[0])>500: self.log.delete('1.0','100.0')
        self.log.see('end'); self.log.configure(state='disabled')

    def _submit(self,operation,success,kind='command'):
        if self.closing: return
        if self.busy:
            if kind!='poll':
                self.pending[kind]=(operation,success)
                self.message.set('已记录最新操作，当前应答完成后立即应用。')
            return
        self.busy=True; self.inflight_kind=kind; self._states()
        future=self.executor.submit(operation)
        future.add_done_callback(lambda result:self.events.put(('done',result,success,kind)))

    def _drain(self):
        while not self.events.empty():
            item=self.events.get_nowait()
            if item[0]=='log': self._log(item[1]); continue
            self.busy=False; self.inflight_kind=None
            try: item[2](item[1].result())
            except Exception as error:
                self.message.set(str(error)); self._log('错误  '+str(error))
                if self.ddr_window is not None and self.ddr_window.winfo_exists():self.ddr_hint.set(str(error))
                if item[3]=='defaults': self.resetting=False
                if item[3].startswith('cnn_') and getattr(self,'cnn_panel',None):self.cnn_panel.fail(error)
            self._states()
            if self.pending:
                kind,(operation,success)=self.pending.popitem(last=False)
                self._submit(operation,success,kind)
        if not self.closing: self._drain_id=self.root.after(5,self._drain)

    def refresh_ports(self):
        try:
            ports=list_ports(); self.port_box.configure(values=[p[0] for p in ports])
            if ports and self.port.get() not in [p[0] for p in ports]: self.port.set(ports[0][0])
            if not ports:
                self.port.set('')
                if self.mode.get()=='串口硬件':
                    self.message.set('未发现 COM 串口；请连接 USB-UART 后刷新。JTAG 下载器不一定提供 COM 口。')
            elif self.mode.get()=='串口硬件':
                self.message.set('可用串口：'+'；'.join(f'{port} · {description}' for port,description in ports))
        except ImportError: self.message.set('请安装串口依赖：python -m pip install -r host/requirements.txt')

    def toggle_connection(self):
        if self.busy or self.pending: return
        if self.client:
            backend=self.client
            def disconnected(_):
                self.frame_frozen=False;self.snapshot_available=False
                self.ddr_status=None;self.ddr_catalog=FrameCatalog();self.ddr_text.set('DDR仓库：未连接');
                if self.ddr_window is not None and self.ddr_window.winfo_exists():self._refresh_ddr_list()
                self.client=None; self.caps=0; self.connection.set('未连接'); self.readback.set('—')
                self.mode_readback.set('当前模式：—'); self.geometry_readback.set('尚未读取图像设置')
                self.message.set('已断开。')
            self._submit(backend.close,disconnected,'disconnect'); return
        try:
            mode,port,baud=self.mode.get(),self.port.get(),int(self.baud.get())
            if not 1200<=baud<=1000000: raise ValueError('波特率无效')
            if mode=='串口硬件' and not port: raise ValueError('未选择可用 COM 串口；请连接 USB-UART 后点击刷新。')
        except ValueError as error: self.message.set(str(error)); return
        def connect():
            try:
                backend=DemoClient(self._trace) if mode=='模拟演示' else SerialClient(port,baud,trace=self._trace)
            except OSError as error:
                raise OSError(f'无法打开 {port}：{error}。请检查端口是否仍存在，以及是否被其他终端占用。') from error
            try:
                status=backend.get_status()
                geometry=backend.get_geometry() if status.capabilities & CAP_CROP else None
            except TimeoutError as error:
                backend.close()
                raise TimeoutError(f'{port} 已打开，但 FPGA 协议握手超时；请确认业务 .bit 已运行（不是 Flash 编程桥）、115200 波特率及 UART 接线。') from error
            except Exception: backend.close(); raise
            try:backend.snapshot_info=store_status(backend)
            except (RuntimeError,ValueError,TimeoutError):backend.snapshot_info=None
            return backend,status,geometry
        def connected(result):
            self.client,status,geometry=result
            self.snapshot_available=self.client.snapshot_info is not None
            self.frame_frozen=False
            if self.client.snapshot_info:self._store_status(self.client.snapshot_info)
            self.connection.set('模拟 · 未连接硬件' if self.client.simulated else f'已连接 {port}')
            self._status(status); self.threshold.set(str(status.threshold))
            self.sobel.set(status.sobel_enabled); self.inverted.set(status.inverted)
            self.median.set(status.median_enabled)
            self.gaussian.set(bool(status.isp_flags&8));self.scharr.set(bool(status.isp_flags&16))
            self.canny.set(bool(status.isp_flags&32));self.preserve.set(bool(status.isp_flags&64))
            if geometry: self._geometry(geometry); self._load_geometry_draft(geometry)
            if getattr(self,'cnn_panel',None) and self.cnn_panel.window.winfo_exists():self.cnn_panel.refresh()
        self._submit(connect,connected,'connect')

    def _status(self,status,announce=True):
        self.caps=status.capabilities; self.readback.set(str(status.threshold))
        self.advanced_available=bool(status.advanced_capabilities)
        prefix='模拟' if self.client.simulated else '设备'
        mode=('选择性中值滤波 + ' if status.median_enabled else '') + (
            'Sobel 强度 · '+('反相' if status.inverted else '白边黑底') if status.sobel_enabled else
            ('灰度图像' if status.median_enabled else '原始图像'))
        if status.isp_flags & 32:mode='Canny（连接范围在算法调节中设置）'
        elif status.isp_flags & 16:mode='Scharr 强度'
        if status.isp_flags & 8:mode='高斯' + ('保边' if status.isp_flags & 64 else '') + ' + ' + mode
        if status.capabilities & CAP_ISP:
            self.mode_readback.set(f'{prefix}已确认：{mode}；黑白反转'+('开启' if status.inverted else '关闭'))
        else:
            mode='模式由旧版bit固定，无法回读'
            self.mode_readback.set(mode)
        self.cap_text.set('中值滤波可用' if status.capabilities & CAP_MEDIAN else
                          '当前 bit 不支持中值滤波' if status.capabilities & CAP_DEFAULTS else
                          '旧版设备：新功能需更新 bit')
        if announce: self.message.set(f'{prefix}已确认：阈值 {status.threshold}，{mode}。')

    def _status_action(self,status):
        self._status(status)
        if not self.client.simulated: self.latency.set(f'最近命令往返 {self.client.last_roundtrip_ms:.1f} ms')

    def apply_threshold(self):
        if not self.client or self.resetting or not self.caps & CAP_THRESHOLD: return
        try: value=int(self.threshold.get()); threshold_payload(value)
        except ValueError: self.message.set('阈值必须为0～4095整数，未发送。'); return
        self.last_interaction=time.monotonic(); backend=self.client
        self._submit(lambda:backend.set_threshold(value),self._status_action,'threshold')

    def apply_isp(self,edge=None):
        if edge and getattr(self,edge).get():
            for name in ('sobel','scharr','canny'):
                if name!=edge:getattr(self,name).set(False)
        if self.canny.get():self.gaussian.set(True)
        if not self.client or self.resetting or not self.caps & CAP_ISP: return
        enabled,inverted,median=self.sobel.get(),self.inverted.get(),self.median.get()
        backend=self.client
        self.last_interaction=time.monotonic()
        args=(enabled,inverted,median,self.gaussian.get(),self.scharr.get(),self.canny.get(),self.preserve.get())
        self._submit(lambda:backend.set_isp(*args),self._status_action,'isp')

    def apply_feature(self,kind):
        if not self.client or self.resetting: return
        cap={'flip':CAP_FLIP,'crop':CAP_CROP,'zoom':CAP_ZOOM}[kind]
        if not self.caps & cap: return
        try:
            if kind=='flip': args=(self.flip.get(),self.flip_horizontal.get())
            elif kind=='crop':
                args=tuple(int(self.crop[k].get()) for k in ('x','y','width','height')); crop_payload(*args)
            else: args=percent_ratio(self.zoom.get())
        except ValueError as error: self.message.set(str(error)); return
        backend=self.client; self.last_interaction=time.monotonic()
        self._submit(lambda:getattr(backend,'set_'+kind)(*args),self._geometry,kind)

    def _geometry(self,g):
        prefix='模拟' if self.client.simulated else '设备'
        self.geometry_readback.set(f'{prefix}已确认：上下'+('开' if g.vertical else '关')+' / 左右'+('开' if g.horizontal else '关')+
            f'；裁剪 ({g.x}, {g.y}, {g.width}, {g.height})；缩放 {g.numerator*100/g.denominator:g}%。')
        self.message.set('图像设置已生效并回读。' if not self.client.simulated else '模拟设置已回读，未连接硬件。')
        if g.faults: self.message.set('设备历史诊断：'+('出现过缺行；' if g.faults&1 else '')+('出现过DDR读错误；' if g.faults&2 else '')+'标志保持至FPGA复位。')

    def _load_geometry_draft(self,g):
        self.flip.set(g.vertical); self.flip_horizontal.set(g.horizontal)
        for name in self.crop: self.crop[name].set(str(getattr(g,name)))
        self.zoom.set(f'{g.numerator*100/g.denominator:g}%')

    def reset_defaults(self):
        if not self.client or self.resetting or not self.caps & CAP_DEFAULTS: return
        # V0.6: defaults supersede unsent edits, never discard an in-flight packet.
        threshold_task=self.pending.get('threshold')
        self.pending.clear()
        if threshold_task: self.pending['threshold']=threshold_task
        self.resetting=True; self._states()
        backend=self.client; self.last_interaction=time.monotonic()
        def updated(result):
            status,geometry=result; self.resetting=False; self._status(status)
            self.sobel.set(status.sobel_enabled); self.inverted.set(status.inverted)
            self.median.set(status.median_enabled)
            self.gaussian.set(bool(status.isp_flags&8));self.scharr.set(bool(status.isp_flags&16))
            self.canny.set(bool(status.isp_flags&32));self.preserve.set(bool(status.isp_flags&64))
            if geometry: self._geometry(geometry); self._load_geometry_draft(geometry)
            self.message.set('已恢复默认，Sobel阈值保持不变。')
        def reset_operation():
            result=backend.reset_defaults()
            if backend.simulated:
                from .camera_controls import camera_defaults
                camera_defaults(backend)
            if self.snapshot_available:
                if backend.simulated:store_control(backend,0)
                backend.snapshot_info=store_status(backend)
            return result
        def reset_updated(result):
            updated(result)
            if self.snapshot_available:self._store_status(backend.snapshot_info)
            if getattr(self,'cnn_panel',None) and self.cnn_panel.window.winfo_exists():self.cnn_panel.refresh()
        self._submit(reset_operation,reset_updated,'defaults')

    def _poll(self):
        # Only one short status request; geometry is read after commands, not every poll.
        if self.auto_poll.get() and self.client and not self.busy and not self.pending and time.monotonic()-self.last_interaction>.3:
            self._submit(self.client.get_status,lambda status:self._status(status,False),'poll')
        if not self.closing: self._poll_id=self.root.after(1500,self._poll)

    # V0.17 / 81: one preview owner per capture device.
    def open_hdmi_preview(self):
        preview=getattr(self,'hdmi_preview',None)
        if preview is not None and preview.win.winfo_exists():
            preview.win.lift();return
        self.hdmi_preview=HDMIPreview(self.root,self.hdmi_source,self.frame_store)

    def close(self):
        if self.closing: return
        self.closing=True; self.ddr_thumb_cancel.set(); self.pending.clear(); client=self.client
        # V0.6: cancel owned timers before destroying Tcl widgets.
        for timer in (self._drain_id,self._poll_id):
            self.root.after_cancel(timer)
        def cleanup():
            if client: client.close()
            self.hdmi_source.close()
            while not self.events.empty():
                item=self.events.get_nowait()
                if item[0]=='done':
                    try:
                        result=item[1].result()
                        if isinstance(result,tuple) and hasattr(result[0],'close'): result[0].close()
                    except Exception: pass
        self.executor.submit(cleanup); self.executor.shutdown(wait=False); self.root.destroy()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--demo',action='store_true')
    args=parser.parse_args()
    root=tk.Tk(); ImageControlApp(root,demo=args.demo); root.mainloop()


if __name__=='__main__': main()
